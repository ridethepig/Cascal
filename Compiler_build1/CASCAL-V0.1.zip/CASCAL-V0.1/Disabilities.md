#Disabilities
###Here are some things that our language can't do:(refrence to c)
>No struct;  
>No libraries;  
>No OOP;  
>No self-increase/decrease("++"/"--");  
>No Declaration Anywhere(only the beginning of a block);  
>No enum;  
>No pointer/refrence;  
>No Binary Compile Support(only bitcode and a virtual machine);  
>No namspace;  
>No Exception Catching;  
>No Binary Operation;  
>No Self-Define Function  
>No Control Flow!!!  
>No Double Type;  
>No Upper or Lower Differences;  
>No Binary File(So Far);  
####I can only come up with these now;